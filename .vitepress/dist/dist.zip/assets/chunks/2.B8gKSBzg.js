const s="/assets/2.B0uTEUcE.png";export{s as _};
